Happy Halloween!

You're such an awesome inspiration to myself, I look forward to being as knowledgeable as you are one day. I'm a vue.net web dev, found out about this challenge today (was fan of the asuka's roast), and learned wpf specifically for this.

- David Duron
https://github.com/emt2dev